package com.example.fitness_app;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class nextscreen1 extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    String buttonvalue;
    Button startBtn;
    private CountDownTimer countDownTimer;
    TextView mtextview;
    private boolean MTimeRunning;
    private long MTimeLeftinmills;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nextscreen1);

        mediaPlayer = MediaPlayer.create(nextscreen1.this, R.raw.background_music);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        Intent intent = getIntent();
        buttonvalue = intent.getStringExtra("value");

        int intvalue = Integer.valueOf(buttonvalue);

        switch (intvalue) {

            case 1:
                setContentView(R.layout.activity_dog);
                break;
            case 2:
                setContentView(R.layout.activity_warrior1);
                break;
            case 3:
                setContentView(R.layout.activity_backlegbend);
                break;
            case 4:
                setContentView(R.layout.activity_resttime);
                break;
            case 5:
                setContentView(R.layout.activity_camel);
                break;
            case 6:
                setContentView(R.layout.activity_catcow);
                break;
            case 7:
                setContentView(R.layout.activity_sidewardlegbend);
                break;
            case 8:
                setContentView(R.layout.activity_resttime2);
                break;
            case 9:
                setContentView(R.layout.activity_legup);
                break;
            case 10:
                setContentView(R.layout.activity_extendedhandandleg);
                break;
            case 11:
                setContentView(R.layout.activity_warrior2);
                break;
            case 12:
                setContentView(R.layout.activity_resttime3);
                break;
            case 13:
                setContentView(R.layout.activity_crow);
                break;
            case 14:
                setContentView(R.layout.activity_legbendup);
                break;
            case 15:
                setContentView(R.layout.activity_childpose);
                break;
            case 16:
                setContentView(R.layout.activity_resttime4);
                break;
            case 17:
                setContentView(R.layout.activity_squatsidewardbend);
                break;
            case 18:
                setContentView(R.layout.activity_snakepose);
                break;
            case 19:
                setContentView(R.layout.activity_legtouchbackward);
                break;
        }


        startBtn = findViewById(R.id.startbutton);
        mtextview = findViewById(R.id.time);


        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MTimeRunning) {

                    stoptimer();

                } else {
                    startTimer();

                }
            }
        });
    }

    private void stoptimer() {
        countDownTimer.cancel();
        MTimeRunning = false;
        startBtn.setText("START");
    }

    private void startTimer() {
        final CharSequence value1 = mtextview.getText();
        String num1 = value1.toString();
        String num2 = num1.substring(0, 2);
        String num3 = num1.substring(3, 5);


        final int number = Integer.valueOf(num2) * 60 + Integer.valueOf(num3);
        MTimeLeftinmills = number * 1000;

        countDownTimer = new CountDownTimer(MTimeLeftinmills, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                MTimeLeftinmills = millisUntilFinished;
                updateTimer();

            }

            @Override
            public void onFinish() {

                int newvalue = Integer.valueOf(buttonvalue) + 1;
                if (newvalue <= 7) {

                    Intent intent = new Intent(nextscreen1.this, nextscreen1.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtra("value", String.valueOf(newvalue));
                    startActivity(intent);
                } else {

                    newvalue = 1;
                    Intent intent = new Intent(nextscreen1.this, nextscreen1.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtra("value", String.valueOf(newvalue));
                    startActivity(intent);

                }

            }
        }.start();
        startBtn.setText("Pause");
        MTimeRunning = true;

    }


    private void updateTimer() {
        int minutes = (int) MTimeLeftinmills / 60000;
        int seconds = (int) MTimeLeftinmills % 60000 / 1000;


        String timeLeftText = "";
        if (minutes < 10)
            timeLeftText = "0";
        timeLeftText = timeLeftText + minutes + ":";
        if (seconds < 10)
            timeLeftText += "0";
        timeLeftText += seconds;
        mtextview.setText(timeLeftText);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }

        @Override
        public void onBackPressed () {
                            Intent intent = new Intent(nextscreen1.this, kidsexer.class);
                            startActivity(intent);
            super.onBackPressed();
    }

}
