package com.example.fitness_app;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class adultsworkout extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adultsworkout);

        newArray= new int[]{

                R.id.arm_cir,R.id.abdominal_brid,R.id.adv_bridge,R.id.alternate_slt,R.id.jump_squat,R.id.abstretch_pose,R.id.armcross_sl,R.id.alternate_sl,R.id.backext_pose,R.id.butterfly_dips,
                R.id.alternate_superman,R.id.birddogs_pose,R.id.crunch_chop,R.id.backext_pose,R.id.curtsy_lunge,R.id.curtsylunge_skr,R.id.bigarm_cir,R.id.bulgarians_ss,R.id.Rest1,R.id.Rest2,

        };

        mediaPlayer = MediaPlayer.create(adultsworkout.this, R.raw.background_music);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

    }

    public void Imagebuttonclicked(View view) {
        for (int i=0; i< newArray.length; i++) {
            if (view.getId() == newArray[i]) {
                int value = i+1;
                Log.i("FIRST",String.valueOf(value));
                Intent intent = new Intent(adultsworkout.this,nextscreen.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    @Override
    public void onBackPressed () {
        Intent intent = new Intent(adultsworkout.this, agebracket.class);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}