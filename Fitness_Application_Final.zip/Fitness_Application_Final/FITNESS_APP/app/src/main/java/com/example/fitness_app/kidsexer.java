package com.example.fitness_app;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class kidsexer extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kidsexer);

        newArray = new int[]{
                R.id.downwardfacingdog_pose, R.id.warrior1_pose, R.id.backlegbend_pose, R.id.resttime_pose, R.id.camel_pose, R.id.catcow_pose,
                R.id.sidewardlegbend_pose, R.id.resttime2_pose, R.id.legup_pose, R.id.extendedhandandleg_pose, R.id.warrior2_pose, R.id.resttime3_pose,
                R.id.crow_pose, R.id.legbendup_pose, R.id.child_pose, R.id.resttime4_pose, R.id.squatsidewardbend_pose, R.id.snake_pose, R.id.legtouchbackward_pose,
        };

        mediaPlayer = MediaPlayer.create(kidsexer.this, R.raw.background_music);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

    }

    public void Imagebuttonclicked(View view) {

        for (int i = 0; i < newArray.length; i++) {

            if (view.getId() == newArray[i]) {
                int value = i + 1;
                Log.i("FIRST", String.valueOf(value));
                Intent intent = new Intent(kidsexer.this, nextscreen1.class);
                intent.putExtra("value", String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    @Override
    public void onBackPressed () {
        Intent intent = new Intent(kidsexer.this, agebracket.class);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}