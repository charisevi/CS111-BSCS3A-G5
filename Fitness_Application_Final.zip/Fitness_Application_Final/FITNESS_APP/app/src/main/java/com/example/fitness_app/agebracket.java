package com.example.fitness_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class agebracket extends AppCompatActivity {

    //
    MediaPlayer mediaPlayer;
    public Button btn;
    public EditText enterage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agebracket);

        btn = (Button) findViewById(R.id.agebutton);
        enterage = (EditText) findViewById(R.id.enterage);

        mediaPlayer = MediaPlayer.create(agebracket.this, R.raw.background_music);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value = enterage.getText().toString();
                int intValue = Integer.parseInt(value);

                if (intValue <= 12) {
                    Intent int1 = new Intent(agebracket.this, kid_load_screen.class);
                    startActivity(int1);
                }


                else if (intValue <= 17){
                    Intent int2 = new Intent(agebracket.this, young_load_screen.class);
                    startActivity(int2);
                }


                else if (intValue >= 18){
                    Intent int3 = new Intent(agebracket.this, adult_load_screen.class);
                    startActivity(int3);
                }

                else{
                    btn.setEnabled(false);
                }
            }

        });
    }

    @Override
    public void onBackPressed () {
        Intent intent = new Intent(agebracket.this, MainActivity2.class);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}