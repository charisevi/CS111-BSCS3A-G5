package com.example.fitness_app;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Youngworkouts extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youngworkouts);

        newArray= new int[]{

                R.id.bow_pose,R.id.anklehops_pose,R.id.bridge_pose,R.id.ankletappushups_pose,R.id.chair_pose,R.id.arnoldshoulderpress_pose,R.id.Rest1,R.id.child_pose,R.id.backstretch_pose,
                R.id.playji_pose,R.id.backleglifts_pose,R.id.crunches_pose,R.id.boxersquatpunch_pose,R.id.Rest2,R.id.rotation_pose,R.id.breakdancerkick_pose,R.id.twist_pose,R.id.burpees_pose,
                R.id.windmill_pose,R.id.calfraises_pose,

        };

        mediaPlayer = MediaPlayer.create(Youngworkouts.this, R.raw.background_music);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

    }


    public void Imagebuttonclicked(View view) {

        for (int i = 0; i < newArray.length; i++) {

            if (view.getId() == newArray[i]) {
                int value = i + 1;
                Log.i("FIRST", String.valueOf(value));
                Intent intent = new Intent(Youngworkouts.this,nextscreen2.class);
                intent.putExtra("value", String.valueOf(value));
                startActivity(intent);
           }
        }
    }

    @Override
    public void onBackPressed () {
        Intent intent = new Intent(Youngworkouts.this, agebracket.class);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}
